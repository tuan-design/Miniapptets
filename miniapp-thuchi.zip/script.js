const urlParams = new URLSearchParams(window.location.search);
const api = urlParams.get("api");
const sheetId = urlParams.get("sheetId");

if (!api || !sheetId) {
  alert("Thiếu api hoặc sheetId trên đường dẫn URL.");
  throw new Error("Thiếu api hoặc sheetId");
}

function callAPI(action, method = "GET", bodyData = null) {
  const url = api + "?action=" + action + "&sheetId=" + sheetId;
  const proxyUrl = "/.netlify/functions/proxy?url=" + encodeURIComponent(url);

  const options = {
    method,
    headers: {
      "Content-Type": "application/x-www-form-urlencoded"
    },
    body: method === "POST" ? new URLSearchParams(bodyData) : undefined
  };

  return fetch(proxyUrl, options).then(res => res.json());
}

function loadCategories() {
  callAPI("getCategories")
    .then(data => {
      const list = document.getElementById("categoryList");
      list.innerHTML = "";
      data.forEach(cat => {
        const li = document.createElement("li");
        li.textContent = cat;
        list.appendChild(li);
      });
    })
    .catch(err => alert("Lỗi tải phân loại: " + err.message));
}

document.getElementById("transactionForm").addEventListener("submit", function(e) {
  e.preventDefault();
  const data = {
    date: document.getElementById("date").value,
    category: document.getElementById("category").value,
    amount: document.getElementById("amount").value,
    note: document.getElementById("note").value,
    action: "addTransaction",
    sheetId
  };
  callAPI("addTransaction", "POST", data)
    .then(res => alert("Đã thêm giao dịch thành công!"))
    .catch(err => alert("Lỗi khi thêm giao dịch: " + err.message));
});

document.addEventListener("DOMContentLoaded", loadCategories);
